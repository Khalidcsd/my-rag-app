# app.py - Dynamic PEGS Requirement Engineering System
# Version 3.0.0 - General Purpose with Database Backend

import os

# Replit-specific: Secrets are automatically available as env vars
# No need for dotenv on Replit
if 'REPL_ID' not in os.environ:
    # Only use dotenv locally
    from dotenv import load_dotenv
    load_dotenv()

# Your existing imports...
from fastapi import FastAPI, UploadFile, File, HTTPException, Depends
from fastapi.responses import HTMLResponse, JSONResponse
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Text, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session, relationship
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import json
from datetime import datetime
import hashlib
import re
from enum import Enum
import asyncio
import httpx
from sqlalchemy import select, or_
from fastapi import APIRouter, HTTPException, Depends
import openai
import anthropic
from groq import Groq
# Temporary - remove when Secrets work
import os

os.environ[
    "GROQ_API_KEY"] = "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"

# === DATABASE SETUP ===
DATABASE_URL = "sqlite:///./requirements.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


# === DATABASE MODELS ===
class Project(Base):
    __tablename__ = "projects"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    description = Column(Text)
    domain = Column(String)  # e.g., "SIS", "Healthcare", "Finance", etc.
    created_at = Column(DateTime, default=datetime.utcnow)
    budget = Column(String)
    timeline = Column(String)
    status = Column(String, default="Active")

    requirements = relationship("Requirement", back_populates="project")
    pegs_analysis = relationship("PEGSAnalysis", back_populates="project")


class Requirement(Base):
    __tablename__ = "requirements"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"))
    requirement_id = Column(String, unique=True, index=True)  # e.g., "REQ-001"
    title = Column(String)
    description = Column(Text)
    pegs_category = Column(String)  # Project, Environment, Goals, System
    priority = Column(String)  # High, Medium, Low
    status = Column(String, default="Draft")  # Draft, Approved, Implemented
    source = Column(String)  # Manual, AI-Generated, Document-Extracted
    confidence_score = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime,
                        default=datetime.utcnow,
                        onupdate=datetime.utcnow)

    project = relationship("Project", back_populates="requirements")
    validations = relationship("RequirementValidation",
                               back_populates="requirement")


class PEGSAnalysis(Base):
    __tablename__ = "pegs_analysis"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"))
    analysis_date = Column(DateTime, default=datetime.utcnow)
    project_score = Column(Float)
    environment_score = Column(Float)
    goals_score = Column(Float)
    system_score = Column(Float)
    overall_completeness = Column(Float)
    insights = Column(Text)

    project = relationship("Project", back_populates="pegs_analysis")


class RequirementValidation(Base):
    __tablename__ = "requirement_validations"

    id = Column(Integer, primary_key=True, index=True)
    requirement_id = Column(Integer, ForeignKey("requirements.id"))
    validation_type = Column(String)  # Manual, Automated, AI
    validator = Column(String)
    result = Column(String)  # Pass, Fail, Needs-Review
    comments = Column(Text)
    validated_at = Column(DateTime, default=datetime.utcnow)

    requirement = relationship("Requirement", back_populates="validations")


# Create tables
Base.metadata.create_all(bind=engine)


# === PYDANTIC MODELS ===
class ProjectCreate(BaseModel):
    name: str
    description: str
    domain: str
    budget: Optional[str] = None
    timeline: Optional[str] = None


class RequirementCreate(BaseModel):
    project_id: int
    title: str
    description: str
    pegs_category: str
    priority: str = "Medium"
    source: str = "Manual"


class PEGSQuery(BaseModel):
    project_id: int
    query: str
    context: Optional[Dict[str, Any]] = {}


class RequirementGeneration(BaseModel):
    project_id: int
    domain: str
    pegs_focus: Optional[str] = None  # Specific PEGS category to focus on
    count: int = 5  # Number of requirements to generate
    context: Dict[str, Any] = {}


# === FASTAPI APP ===
app = FastAPI(title="PEGS Requirement Engineering System", version="3.0.0")

# Add this RIGHT AFTER your RequirementValidation class (around line 90-100)


# === CHAT HISTORY MODEL ===
class ChatHistory(Base):
    __tablename__ = "chat_history"

    id = Column(Integer, primary_key=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    message = Column(Text)
    response = Column(Text)
    provider = Column(String)
    sources = Column(Text)
    confidence = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)


# Make sure to recreate tables
Base.metadata.create_all(bind=engine)


# === CHAT PYDANTIC MODELS ===
class ChatQuery(BaseModel):
    message: str
    provider: str = "knowledge_base"
    project_id: Optional[int] = None
    context_window: int = 5
    include_requirements: bool = True


class ChatResponse(BaseModel):
    response: str
    provider: str
    sources: List[Dict] = []
    confidence: float
    processing_time: float


# === KNOWLEDGE BASE RAG CLASS ===
class KnowledgeBaseRAG:

    def __init__(self, db_session):
        self.db = db_session

    def search_requirements(self,
                            query: str,
                            project_id: Optional[int] = None,
                            limit: int = 5) -> List[Dict]:
        search_terms = query.lower().split()
        query_obj = self.db.query(Requirement)

        if project_id:
            query_obj = query_obj.filter(Requirement.project_id == project_id)

        conditions = []
        for term in search_terms:
            conditions.append(Requirement.title.ilike(f"%{term}%"))
            conditions.append(Requirement.description.ilike(f"%{term}%"))

        if conditions:
            query_obj = query_obj.filter(or_(*conditions))

        requirements = query_obj.limit(limit).all()

        return [{
            "id": req.requirement_id,
            "title": req.title,
            "description": req.description,
            "pegs_category": req.pegs_category,
            "confidence": req.confidence_score
        } for req in requirements]

    def generate_context_prompt(self,
                                query: str,
                                project_id: Optional[int] = None) -> str:
        context_parts = []

        if project_id:
            project = self.db.query(Project).filter(
                Project.id == project_id).first()
            if project:
                context_parts.append(
                    f"Project: {project.name} ({project.domain} domain)")

        requirements = self.search_requirements(query, project_id)
        if requirements:
            context_parts.append("\nRelevant Requirements:")
            for req in requirements[:3]:
                context_parts.append(f"- {req['id']}: {req['description']}")

        context = "\n".join(context_parts)
        return f"Context: {context}\n\nQuery: {query}"


# === AI PROVIDER MANAGER ===
class AIProviderManager:

    def __init__(self):
        self.providers = {
            "openai": self.query_openai,
            "anthropic": self.query_anthropic,
            "groq": self.query_groq,
            "gemini": self.query_gemini
        }

        # Initialize clients safely
        try:
            if os.getenv("OPENAI_API_KEY"):
                self.openai_client = openai.OpenAI(
                    api_key=os.getenv("OPENAI_API_KEY"))
            else:
                self.openai_client = None
        except:
            self.openai_client = None

        try:
            if os.getenv("ANTHROPIC_API_KEY"):
                self.anthropic_client = anthropic.Anthropic(
                    api_key=os.getenv("ANTHROPIC_API_KEY"))
            else:
                self.anthropic_client = None
        except:
            self.anthropic_client = None

        try:
            if os.getenv("GROQ_API_KEY"):
                self.groq_client = Groq(api_key=os.getenv("GROQ_API_KEY"))
            else:
                self.groq_client = None
        except:
            self.groq_client = None

    async def query_openai(self, prompt: str) -> str:
        if not self.openai_client:
            return "OpenAI not configured"
        try:
            response = self.openai_client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{
                    "role": "user",
                    "content": prompt
                }],
                max_tokens=200)
            return response.choices[0].message.content
        except Exception as e:
            return f"OpenAI Error: {str(e)}"

    async def query_anthropic(self, prompt: str) -> str:
        if not self.anthropic_client:
            return "Anthropic not configured"
        try:
            response = self.anthropic_client.messages.create(
                model="claude-3-haiku-20240307",
                max_tokens=200,
                messages=[{
                    "role": "user",
                    "content": prompt
                }])
            return response.content[0].text
        except Exception as e:
            return f"Anthropic Error: {str(e)}"

    async def query_groq(self, prompt: str) -> str:
        if not self.groq_client:
            return "Groq not configured"
        try:
            response = self.groq_client.chat.completions.create(
                model="mixtral-8x7b-32768",
                messages=[{
                    "role": "user",
                    "content": prompt
                }],
                max_tokens=200)
            return response.choices[0].message.content
        except Exception as e:
            return f"Groq Error: {str(e)}"

    async def query_gemini(self, prompt: str) -> str:
        return "Gemini integration pending"


# === DATABASE SETUP ===
DATABASE_URL = "sqlite:///./requirements.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# === DATABASE MODELS ===
# Your existing models (Project, Requirement, etc.)


# === ADD: CHAT HISTORY MODEL ===
class ChatHistory(Base):
    __tablename__ = "chat_history"

    id = Column(Integer,
                primary_key=True)  # ← Make sure primary_key=True is here!
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    message = Column(Text)
    response = Column(Text)
    provider = Column(String)
    sources = Column(Text)
    confidence = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)


# Create tables
Base.metadata.create_all(bind=engine)

# === PYDANTIC MODELS ===
# Your existing pydantic models

# === FASTAPI APP ===
app = FastAPI(title="PEGS Requirement Engineering System", version="3.0.0")


# === DEFINE get_db HERE (BEFORE chat router!) ===
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# === THEN ADD CHAT COMPONENTS ===
# KnowledgeBaseRAG class
# AIProviderManager class
# chat_router definition


# === CREATE CHAT ROUTER ===
async def query_gemini(self, prompt: str) -> str:
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        return "Gemini not configured"
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent",
                params={"key": api_key},
                json={
                    "contents": [{
                        "parts": [{
                            "text": prompt
                        }]
                    }],
                    "generationConfig": {
                        "maxOutputTokens": 200
                    }
                })
            data = response.json()
            return data["candidates"][0]["content"]["parts"][0]["text"]
    except Exception as e:
        return f"Gemini Error: {str(e)}"


# NOW the chat_router line can be at the same indentation level
chat_router = APIRouter(prefix="/api/chat", tags=["chat"])


@chat_router.post("/query")
async def chat_query(query: ChatQuery, db: Session = Depends(get_db)):
    start_time = datetime.now()

    kb_rag = KnowledgeBaseRAG(db)
    ai_manager = AIProviderManager()

    response_text = ""
    sources = []
    confidence = 0.0

    if query.provider == "knowledge_base":
        requirements = kb_rag.search_requirements(query.message,
                                                  query.project_id)
        sources = requirements

        if requirements:
            response_text = "Based on your requirements:\n\n"
            for req in requirements[:3]:
                response_text += f"• {req['title']}: {req['description']}\n"
            confidence = 0.85
        else:
            response_text = "No requirements found. Try generating some first."
            confidence = 0.0

    elif query.provider in ai_manager.providers:
        enhanced_prompt = kb_rag.generate_context_prompt(
            query.message, query.project_id)
        provider_func = ai_manager.providers[query.provider]
        response_text = await provider_func(enhanced_prompt)
        confidence = 0.8

    else:
        response_text = "Provider not available"
        confidence = 0.0

    processing_time = (datetime.now() - start_time).total_seconds()

    return ChatResponse(response=response_text,
                        provider=query.provider,
                        sources=sources,
                        confidence=confidence,
                        processing_time=processing_time)


# NOW you can include the router (this should be around line 150)
# app.include_router(chat_router)  # This line should ALREADY exist in your code
# After creating your FastAPI app, add:
app.include_router(chat_router)


# Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# === PEGS FRAMEWORK ENGINE ===
class PEGSFramework:
    """Dynamic PEGS Framework for any domain"""

    @staticmethod
    def get_domain_template(domain: str) -> Dict:
        """Get PEGS template for specific domain"""
        templates = {
            "SIS": {
                "Project": [
                    "Timeline", "Budget", "Resources", "Methodology",
                    "Milestones"
                ],
                "Environment": [
                    "Compliance", "Integration", "Stakeholders",
                    "Infrastructure"
                ],
                "Goals":
                ["Performance", "ROI", "User Satisfaction", "Efficiency"],
                "System":
                ["Architecture", "Security", "Scalability", "Performance"]
            },
            "Healthcare": {
                "Project": [
                    "Implementation phases", "Staff training",
                    "Budget allocation", "Risk management"
                ],
                "Environment": [
                    "HIPAA compliance", "Hospital systems", "Medical devices",
                    "Regulations"
                ],
                "Goals": [
                    "Patient outcomes", "Cost reduction", "Staff efficiency",
                    "Quality metrics"
                ],
                "System": [
                    "EMR integration", "Data security", "Interoperability",
                    "Availability"
                ]
            },
            "Finance": {
                "Project": [
                    "Rollout strategy", "Team structure",
                    "Capital requirements", "Timeline"
                ],
                "Environment": [
                    "Regulatory compliance", "Market conditions",
                    "Partner banks", "Audits"
                ],
                "Goals": [
                    "Transaction volume", "Revenue targets",
                    "Customer acquisition", "Risk metrics"
                ],
                "System": [
                    "Transaction processing", "Security protocols", "APIs",
                    "Disaster recovery"
                ]
            },
            "Generic": {
                "Project": [
                    "Schedule", "Budget", "Resources", "Deliverables",
                    "Dependencies"
                ],
                "Environment": [
                    "Regulations", "Stakeholders", "External systems",
                    "Constraints"
                ],
                "Goals":
                ["Objectives", "KPIs", "Success criteria", "Benefits"],
                "System":
                ["Technical specs", "Architecture", "Performance", "Security"]
            }
        }
        return templates.get(domain, templates["Generic"])

    @staticmethod
    def generate_requirements(domain: str, category: str, count: int,
                              context: Dict) -> List[Dict]:
        """Generate requirements based on domain and PEGS category"""
        template = PEGSFramework.get_domain_template(domain)
        requirements = []

        # Domain-specific requirement patterns
        patterns = {
            "Project": [
                "The system shall complete {phase} within {timeline}",
                "The project shall maintain {resource} utilization below {threshold}",
                "All deliverables shall meet {standard} quality criteria"
            ],
            "Environment": [
                "The system shall comply with {regulation} standards",
                "Integration with {system} shall be completed using {protocol}",
                "All stakeholder {type} shall have access to {feature}"
            ],
            "Goals": [
                "The system shall achieve {metric}% improvement in {area}",
                "User satisfaction shall exceed {threshold}% within {period}",
                "ROI shall reach {percentage}% by {date}"
            ],
            "System": [
                "The system shall support {number} concurrent users",
                "Response time shall not exceed {time} seconds for {operation}",
                "System availability shall be maintained at {percentage}%"
            ]
        }

        # Generate requirements
        for i in range(count):
            req_patterns = patterns.get(category, patterns["System"])
            pattern = req_patterns[i % len(req_patterns)]

            # Fill in template with context or defaults
            requirement = {
                "title":
                f"{domain} {category} Requirement {i+1}",
                "description":
                pattern.format(phase=context.get("phase", "Phase 1"),
                               timeline=context.get("timeline", "6 months"),
                               resource=context.get("resource", "CPU"),
                               threshold=context.get("threshold", "80"),
                               standard=context.get("standard", "ISO"),
                               regulation=context.get("regulation",
                                                      "Industry"),
                               system=context.get("system", "External System"),
                               protocol=context.get("protocol", "REST API"),
                               type=context.get("type", "communication"),
                               feature=context.get("feature", "dashboard"),
                               metric=context.get("metric", "25"),
                               area=context.get("area", "efficiency"),
                               percentage=context.get("percentage", "60"),
                               date=context.get("date", "Year 2"),
                               number=context.get("number", "1000"),
                               time=context.get("time", "2"),
                               operation=context.get("operation", "query"),
                               period=context.get("period", "first quarter")),
                "pegs_category":
                category,
                "priority":
                "High" if i < count // 3 else "Medium" if i < 2 * count //
                3 else "Low",
                "confidence_score":
                0.85 + (i * 0.02)
            }
            requirements.append(requirement)

        return requirements

    @staticmethod
    def analyze_completeness(requirements: List) -> Dict:
        """Analyze PEGS completeness for a set of requirements"""
        pegs_counts = {"Project": 0, "Environment": 0, "Goals": 0, "System": 0}

        for req in requirements:
            if req.pegs_category in pegs_counts:
                pegs_counts[req.pegs_category] += 1

        total = sum(pegs_counts.values())
        if total == 0:
            return {
                "completeness": 0,
                "distribution": pegs_counts,
                "gaps": list(pegs_counts.keys())
            }

        distribution = {k: (v / total) * 100 for k, v in pegs_counts.items()}
        ideal_percentage = 25  # Each category should ideally be 25%

        gaps = [
            k for k, v in distribution.items() if v < ideal_percentage - 10
        ]
        strong_areas = [
            k for k, v in distribution.items() if v > ideal_percentage + 10
        ]

        completeness_score = 100 - sum(
            abs(v - ideal_percentage) for v in distribution.values()) / 4

        return {
            "completeness": completeness_score,
            "distribution": distribution,
            "gaps": gaps,
            "strong_areas": strong_areas,
            "total_requirements": total,
            "pegs_counts": pegs_counts
        }


# === API ENDPOINTS ===


@app.get("/")
def home():
    return {
        "status":
        "operational",
        "name":
        "PEGS Requirement Engineering System",
        "version":
        "3.0.0",
        "features": [
            "Dynamic domain support", "PEGS framework analysis",
            "Requirement generation", "Database backend", "Validation system"
        ]
    }


@app.post("/projects")
def create_project(project: ProjectCreate, db: Session = Depends(get_db)):
    """Create a new project"""
    db_project = Project(**project.dict())
    db.add(db_project)
    db.commit()
    db.refresh(db_project)
    return db_project


@app.get("/projects")
def list_projects(db: Session = Depends(get_db)):
    """List all projects"""
    projects = db.query(Project).all()
    return projects


@app.get("/projects/{project_id}")
def get_project(project_id: int, db: Session = Depends(get_db)):
    """Get project details with requirements"""
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    requirements = db.query(Requirement).filter(
        Requirement.project_id == project_id).all()
    analysis = PEGSFramework.analyze_completeness(requirements)

    return {
        "project": project,
        "requirements_count": len(requirements),
        "pegs_analysis": analysis
    }


@app.post("/requirements")
def create_requirement(requirement: RequirementCreate,
                       db: Session = Depends(get_db)):
    """Create a new requirement"""
    # Generate unique requirement ID
    req_count = db.query(Requirement).filter(
        Requirement.project_id == requirement.project_id).count()
    req_id = f"REQ-{requirement.project_id:03d}-{req_count+1:04d}"

    db_requirement = Requirement(**requirement.dict(),
                                 requirement_id=req_id,
                                 confidence_score=0.95)
    db.add(db_requirement)
    db.commit()
    db.refresh(db_requirement)
    return db_requirement


@app.post("/requirements/generate")
def generate_requirements(generation: RequirementGeneration,
                          db: Session = Depends(get_db)):
    """Generate requirements using PEGS framework"""
    project = db.query(Project).filter(
        Project.id == generation.project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    generated_reqs = []

    if generation.pegs_focus:
        # Generate for specific PEGS category
        reqs = PEGSFramework.generate_requirements(generation.domain,
                                                   generation.pegs_focus,
                                                   generation.count,
                                                   generation.context)
    else:
        # Generate balanced across all PEGS categories
        reqs = []
        per_category = max(1, generation.count // 4)
        for category in ["Project", "Environment", "Goals", "System"]:
            category_reqs = PEGSFramework.generate_requirements(
                generation.domain, category, per_category, generation.context)
            reqs.extend(category_reqs)

    # Save to database
    for req in reqs:
        req_count = db.query(Requirement).filter(
            Requirement.project_id == generation.project_id).count()
        req_id = f"REQ-{generation.project_id:03d}-{req_count+1:04d}"

        db_requirement = Requirement(project_id=generation.project_id,
                                     requirement_id=req_id,
                                     title=req["title"],
                                     description=req["description"],
                                     pegs_category=req["pegs_category"],
                                     priority=req["priority"],
                                     source="AI-Generated",
                                     confidence_score=req["confidence_score"])
        db.add(db_requirement)
        generated_reqs.append(db_requirement)

    db.commit()

    return {
        "generated_count": len(generated_reqs),
        "requirements": generated_reqs
    }


@app.get("/requirements/{project_id}")
def get_requirements(project_id: int,
                     pegs_category: Optional[str] = None,
                     db: Session = Depends(get_db)):
    """Get requirements for a project"""
    query = db.query(Requirement).filter(Requirement.project_id == project_id)

    if pegs_category:
        query = query.filter(Requirement.pegs_category == pegs_category)

    requirements = query.all()
    return requirements


@app.post("/analyze/{project_id}")
def analyze_project(project_id: int, db: Session = Depends(get_db)):
    """Perform PEGS analysis on a project"""
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")

    requirements = db.query(Requirement).filter(
        Requirement.project_id == project_id).all()
    analysis = PEGSFramework.analyze_completeness(requirements)

    # Calculate scores
    pegs_scores = {"Project": 0, "Environment": 0, "Goals": 0, "System": 0}

    for category in pegs_scores.keys():
        cat_reqs = [r for r in requirements if r.pegs_category == category]
        if cat_reqs:
            # Score based on count and priority
            high_priority = len([r for r in cat_reqs if r.priority == "High"])
            medium_priority = len(
                [r for r in cat_reqs if r.priority == "Medium"])
            low_priority = len([r for r in cat_reqs if r.priority == "Low"])

            score = (high_priority * 3 + medium_priority * 2 +
                     low_priority) / max(1, len(cat_reqs))
            pegs_scores[category] = min(100, score * 33.33)

    # Save analysis
    db_analysis = PEGSAnalysis(project_id=project_id,
                               project_score=pegs_scores["Project"],
                               environment_score=pegs_scores["Environment"],
                               goals_score=pegs_scores["Goals"],
                               system_score=pegs_scores["System"],
                               overall_completeness=analysis["completeness"],
                               insights=json.dumps({
                                   "distribution":
                                   analysis["distribution"],
                                   "gaps":
                                   analysis["gaps"],
                                   "strong_areas":
                                   analysis.get("strong_areas", []),
                                   "total_requirements":
                                   analysis["total_requirements"]
                               }))

    db.add(db_analysis)
    db.commit()

    return {
        "analysis_id": db_analysis.id,
        "pegs_scores": pegs_scores,
        "completeness": analysis["completeness"],
        "distribution": analysis["distribution"],
        "gaps": analysis["gaps"],
        "strong_areas": analysis.get("strong_areas", []),
        "recommendations": generate_recommendations(analysis)
    }


def generate_recommendations(analysis: Dict) -> List[str]:
    """Generate recommendations based on PEGS analysis"""
    recommendations = []

    if analysis["completeness"] < 70:
        recommendations.append(
            "Overall completeness is low. Consider adding more requirements across all categories."
        )

    for gap in analysis.get("gaps", []):
        recommendations.append(
            f"Gap identified in {gap} category. Focus on adding {gap}-related requirements."
        )

    for strong in analysis.get("strong_areas", []):
        recommendations.append(
            f"{strong} category is well-covered. Consider balancing with other areas."
        )

    if analysis["total_requirements"] < 20:
        recommendations.append(
            "Total requirement count is low. Consider generating more requirements for comprehensive coverage."
        )

    return recommendations


@app.post("/upload/{project_id}")
async def upload_document(project_id: int,
                          file: UploadFile = File(...),
                          db: Session = Depends(get_db)):
    """Upload and extract requirements from documents"""
    content = await file.read()
    text = content.decode('utf-8', errors='ignore')

    # Simple requirement extraction (enhance with NLP in production)
    requirements = []
    patterns = [
        r"(?:shall|must|will|should)\s+(.+?)(?:\.|;|\n)",
        r"(?:requirement|REQ-\d+):\s*(.+?)(?:\.|;|\n)",
        r"(?:As a .+?, I want .+? so that .+?)(?:\.|;|\n)"
    ]

    for pattern in patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        for match in matches:
            if len(match) > 20:  # Filter out too short matches
                requirements.append(match.strip())

    # Classify requirements using keywords
    saved_reqs = []
    for req_text in requirements[:20]:  # Limit to 20 requirements
        category = classify_requirement(req_text)

        req_count = db.query(Requirement).filter(
            Requirement.project_id == project_id).count()
        req_id = f"REQ-{project_id:03d}-{req_count+1:04d}"

        db_requirement = Requirement(project_id=project_id,
                                     requirement_id=req_id,
                                     title=f"Extracted: {req_text[:50]}...",
                                     description=req_text,
                                     pegs_category=category,
                                     priority="Medium",
                                     source="Document-Extracted",
                                     confidence_score=0.75)
        db.add(db_requirement)
        saved_reqs.append(db_requirement)

    db.commit()

    return {
        "filename": file.filename,
        "requirements_found": len(requirements),
        "requirements_saved": len(saved_reqs),
        "extraction_summary": {
            "Project":
            len([r for r in saved_reqs if r.pegs_category == "Project"]),
            "Environment":
            len([r for r in saved_reqs if r.pegs_category == "Environment"]),
            "Goals":
            len([r for r in saved_reqs if r.pegs_category == "Goals"]),
            "System":
            len([r for r in saved_reqs if r.pegs_category == "System"])
        }
    }


def classify_requirement(text: str) -> str:
    """Classify requirement into PEGS category using keywords"""
    text_lower = text.lower()

    project_keywords = [
        "timeline", "budget", "resource", "milestone", "phase", "deliverable",
        "schedule"
    ]
    environment_keywords = [
        "compliance", "regulation", "integration", "stakeholder", "policy",
        "standard"
    ]
    goals_keywords = [
        "objective", "target", "kpi", "metric", "success", "roi",
        "performance", "efficiency"
    ]
    system_keywords = [
        "architecture", "database", "api", "security", "interface",
        "component", "module"
    ]

    scores = {
        "Project": sum(1 for kw in project_keywords if kw in text_lower),
        "Environment":
        sum(1 for kw in environment_keywords if kw in text_lower),
        "Goals": sum(1 for kw in goals_keywords if kw in text_lower),
        "System": sum(1 for kw in system_keywords if kw in text_lower)
    }

    # Return category with highest score, default to System
    max_category = max(scores, key=scores.get)
    return max_category if scores[max_category] > 0 else "System"


@app.get("/dashboard", response_class=HTMLResponse)
def dashboard():
    """Enhanced dashboard for PEGS Requirement Engineering"""
    return """<!DOCTYPE html>
<html>
<head>
    <title>PEGS Requirement Engineering System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.1);
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding: 30px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-radius: 15px;
        }
        .header h1 { font-size: 2.5rem; margin-bottom: 10px; }
        .header p { opacity: 0.9; }

        .tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            flex-wrap: wrap;
            justify-content: center;
        }
        .tab {
            padding: 12px 24px;
            background: #f0f0f0;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s;
        }
        .tab.active {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            transform: translateY(-2px);
        }
        .tab:hover { transform: translateY(-2px); }

        .content-section {
            display: none;
            animation: fadeIn 0.5s;
        }
        .content-section.active { display: block; }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .form-group {
            margin-bottom: 20px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #333;
        }
        .form-control {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        .form-control:focus {
            outline: none;
            border-color: #667eea;
        }

        .btn {
            padding: 12px 24px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }

        .pegs-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        .pegs-card {
            padding: 20px;
            background: #f8f9fa;
            border-radius: 15px;
            border-left: 4px solid #667eea;
            transition: all 0.3s;
        }
        .pegs-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        }
        .pegs-card h3 {
            color: #667eea;
            margin-bottom: 10px;
        }

        .requirements-list {
            max-height: 400px;
            overflow-y: auto;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 10px;
        }
        .requirement-item {
            padding: 15px;
            margin-bottom: 10px;
            background: white;
            border-radius: 10px;
            border-left: 3px solid #667eea;
        }
        .requirement-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        .requirement-id {
            font-weight: bold;
            color: #667eea;
        }
        .pegs-badge {
            padding: 4px 12px;
            background: #667eea;
            color: white;
            border-radius: 15px;
            font-size: 0.85rem;
        }

        /* Chat Styles */
        .chat-button {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            cursor: pointer;
            font-size: 1.5rem;
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
            z-index: 999;
            transition: all 0.3s;
        }
        .chat-button:hover {
            transform: scale(1.1);
        }

        .chat-container {
            position: fixed;
            bottom: 90px;
            right: 20px;
            width: 400px;
            height: 600px;
            display: none;
            flex-direction: column;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            z-index: 1000;
        }

        .chat-header {
            padding: 20px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border-radius: 15px 15px 0 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .provider-selector {
            padding: 15px;
            background: #f8f9fa;
            border-bottom: 1px solid #e0e0e0;
        }

        .provider-chips {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 10px;
        }

        .provider-chip {
            padding: 6px 12px;
            border-radius: 20px;
            background: white;
            border: 2px solid #e0e0e0;
            cursor: pointer;
            font-size: 0.85rem;
            transition: all 0.3s;
        }

        .provider-chip.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }

        .chat-messages {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background: #f8f9fa;
        }

        .message {
            margin-bottom: 15px;
            padding: 12px 16px;
            border-radius: 15px;
            max-width: 80%;
            word-wrap: break-word;
        }

        .message.user {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            margin-left: auto;
        }

        .message.bot {
            background: white;
            border: 1px solid #e0e0e0;
        }

        .message-meta {
            font-size: 0.75rem;
            color: #666;
            margin-top: 5px;
        }

        .sources-list {
            margin-top: 10px;
            padding: 10px;
            background: #f0f0f0;
            border-radius: 8px;
            font-size: 0.85rem;
        }

        .chat-input-container {
            padding: 20px;
            border-top: 1px solid #e0e0e0;
            display: flex;
            gap: 10px;
        }

        .chat-input {
            flex: 1;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 25px;
            outline: none;
        }

        .chat-send {
            padding: 12px 20px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            border-radius: 25px;
            cursor: pointer;
        }

        .typing-indicator {
            display: none;
            padding: 10px;
            background: white;
            border-radius: 15px;
            border: 1px solid #e0e0e0;
            margin: 0 20px 10px 20px;
        }

        .typing-dot {
            display: inline-block;
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #667eea;
            margin: 0 2px;
            animation: typing 1.4s infinite;
        }

        @keyframes typing {
            0%, 60%, 100% { opacity: 0.3; }
            30% { opacity: 1; }
        }

        @media (max-width: 768px) {
            .chat-container {
                width: 90vw;
                right: 5vw;
                height: 80vh;
                bottom: 80px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎯 PEGS Requirement Engineering System</h1>
            <p>Dynamic Requirements Generation & Analysis Platform with Multi-AI Chat</p>
        </div>

        <div class="tabs">
            <button class="tab active" onclick="switchTab('projects')">📁 Projects</button>
            <button class="tab" onclick="switchTab('generate')">🤖 Generate</button>
            <button class="tab" onclick="switchTab('analyze')">📊 Analyze</button>
            <button class="tab" onclick="switchTab('upload')">📤 Upload</button>
            <button class="tab" onclick="switchTab('pegs')">🧩 PEGS Guide</button>
        </div>

        <!-- Projects Tab -->
        <div id="projects-section" class="content-section active">
            <h2>Project Management</h2>
            <div class="form-group">
                <h3>Create New Project</h3>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <input type="text" id="projectName" class="form-control" placeholder="Project Name">
                    <select id="projectDomain" class="form-control">
                        <option value="SIS">Student Information System</option>
                        <option value="Healthcare">Healthcare System</option>
                        <option value="Finance">Financial Platform</option>
                        <option value="Generic">Generic Project</option>
                    </select>
                </div>
                <textarea id="projectDesc" class="form-control" placeholder="Project Description" style="margin-top: 15px; height: 100px;"></textarea>
                <button class="btn" onclick="createProject()" style="margin-top: 15px;">Create Project</button>
            </div>

            <h3 style="margin-top: 30px;">Existing Projects</h3>
            <div id="projectsList" class="requirements-list"></div>
        </div>

        <!-- Generate Tab -->
        <div id="generate-section" class="content-section">
            <h2>Generate Requirements</h2>
            <div class="form-group">
                <label>Select Project</label>
                <select id="genProjectId" class="form-control"></select>
            </div>
            <div class="form-group">
                <label>PEGS Category Focus (Optional)</label>
                <select id="pegsFocus" class="form-control">
                    <option value="">All Categories (Balanced)</option>
                    <option value="Project">Project</option>
                    <option value="Environment">Environment</option>
                    <option value="Goals">Goals</option>
                    <option value="System">System</option>
                </select>
            </div>
            <div class="form-group">
                <label>Number of Requirements</label>
                <input type="number" id="reqCount" class="form-control" value="8" min="1" max="50">
            </div>
            <button class="btn" onclick="generateRequirements()">🤖 Generate Requirements</button>
            <div id="generatedReqs" style="margin-top: 30px;"></div>
        </div>

        <!-- Analyze Tab -->
        <div id="analyze-section" class="content-section">
            <h2>PEGS Analysis</h2>
            <div class="form-group">
                <label>Select Project for Analysis</label>
                <select id="analyzeProjectId" class="form-control"></select>
            </div>
            <button class="btn" onclick="analyzeProject()">📊 Run PEGS Analysis</button>
            <div id="analysisResults" style="margin-top: 30px;">
                <div class="pegs-grid" id="pegsScores"></div>
                <div id="recommendations"></div>
            </div>
        </div>

        <!-- Upload Tab -->
        <div id="upload-section" class="content-section">
            <h2>Document Upload</h2>
            <div class="form-group">
                <label>Select Project</label>
                <select id="uploadProjectId" class="form-control"></select>
            </div>
            <div style="border: 2px dashed #667eea; border-radius: 15px; padding: 40px; text-align: center; cursor: pointer; margin: 20px 0;" onclick="document.getElementById('fileInput').click()">
                <h3>📄 Click to Upload Document</h3>
                <p>Extract requirements from your documents</p>
                <input type="file" id="fileInput" style="display: none;" accept=".txt,.doc,.docx,.pdf">
            </div>
            <div id="uploadResults"></div>
        </div>

        <!-- PEGS Guide Tab -->
        <div id="pegs-section" class="content-section">
            <h2>PEGS Framework Guide</h2>
            <div class="pegs-grid">
                <div class="pegs-card">
                    <h3>📋 Project</h3>
                    <p><strong>Focus:</strong> Development lifecycle</p>
                    <ul style="margin-top: 10px; padding-left: 20px;">
                        <li>Timeline and milestones</li>
                        <li>Budget allocation</li>
                        <li>Resource management</li>
                    </ul>
                </div>
                <div class="pegs-card">
                    <h3>🌐 Environment</h3>
                    <p><strong>Focus:</strong> Context and constraints</p>
                    <ul style="margin-top: 10px; padding-left: 20px;">
                        <li>Regulatory compliance</li>
                        <li>Stakeholder needs</li>
                        <li>System integrations</li>
                    </ul>
                </div>
                <div class="pegs-card">
                    <h3>🎯 Goals</h3>
                    <p><strong>Focus:</strong> Success metrics</p>
                    <ul style="margin-top: 10px; padding-left: 20px;">
                        <li>Business objectives</li>
                        <li>KPIs and metrics</li>
                        <li>ROI targets</li>
                    </ul>
                </div>
                <div class="pegs-card">
                    <h3>⚙️ System</h3>
                    <p><strong>Focus:</strong> Technical specs</p>
                    <ul style="margin-top: 10px; padding-left: 20px;">
                        <li>Architecture design</li>
                        <li>Security protocols</li>
                        <li>Performance specs</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Enhanced Chat Widget -->
    <button class="chat-button" onclick="toggleChat()">💬</button>

    <div class="chat-container" id="chatContainer">
        <div class="chat-header">
            <h3>🤖 Multi-AI Assistant</h3>
            <button onclick="toggleChat()" style="background: none; border: none; color: white; cursor: pointer; font-size: 1.5rem;">×</button>
        </div>

        <div class="provider-selector">
            <label style="font-size: 0.9rem;">Select AI Provider:</label>
            <div class="provider-chips">
                <div class="provider-chip active" onclick="selectProvider('knowledge_base')">📚 Knowledge Base</div>
                <div class="provider-chip" onclick="selectProvider('openai')">🧠 ChatGPT</div>
                <div class="provider-chip" onclick="selectProvider('anthropic')">🎭 Claude</div>
                <div class="provider-chip" onclick="selectProvider('groq')">⚡ Groq</div>
                <div class="provider-chip" onclick="selectProvider('gemini')">💎 Gemini</div>
                <div class="provider-chip" onclick="selectProvider('all')">🌐 All</div>
            </div>
        </div>

        <div class="chat-messages" id="chatMessages">
            <div class="message bot">
                <strong>AI Assistant</strong><br>
                Hello! I can help you with requirements engineering using the PEGS framework. Select a provider above or ask me anything!
                <div class="message-meta">Ready to help</div>
            </div>
        </div>

        <div class="typing-indicator" id="typingIndicator">
            <span class="typing-dot" style="animation-delay: 0s;"></span>
            <span class="typing-dot" style="animation-delay: 0.2s;"></span>
            <span class="typing-dot" style="animation-delay: 0.4s;"></span>
            <span> Thinking...</span>
        </div>

        <div class="chat-input-container">
            <input type="text" class="chat-input" id="chatInput" placeholder="Ask about requirements, PEGS analysis..." onkeypress="handleChatKeyPress(event)">
            <button class="chat-send" onclick="sendChatMessage()">Send</button>
        </div>
    </div>

    <script>
        let selectedProvider = 'knowledge_base';
        let chatOpen = false;
        let currentProjectId = null;

        // Tab switching
        function switchTab(tabName) {
            document.querySelectorAll('.content-section').forEach(section => {
                section.classList.remove('active');
            });
            document.querySelectorAll('.tab').forEach(tab => {
                tab.classList.remove('active');
            });

            document.getElementById(tabName + '-section').classList.add('active');
            event.target.classList.add('active');

            if (tabName === 'projects') loadProjects();
        }

        // Chat functions
        function toggleChat() {
            const chat = document.getElementById('chatContainer');
            chatOpen = !chatOpen;
            chat.style.display = chatOpen ? 'flex' : 'none';
        }

        function selectProvider(provider) {
            selectedProvider = provider;
            document.querySelectorAll('.provider-chip').forEach(chip => {
                chip.classList.remove('active');
            });
            event.target.classList.add('active');
        }

        async function sendChatMessage() {
            const input = document.getElementById('chatInput');
            const message = input.value.trim();

            if (!message) return;

            // Add user message
            addMessage(message, 'user');
            input.value = '';

            // Show typing indicator
            document.getElementById('typingIndicator').style.display = 'block';

            // Get current project ID from dropdown
            const projectSelect = document.getElementById('genProjectId');
            if (projectSelect && projectSelect.value) {
                currentProjectId = parseInt(projectSelect.value);
            }

            try {
                const response = await fetch('/api/chat/query', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({
                        message: message,
                        provider: selectedProvider,
                        project_id: currentProjectId,
                        include_requirements: true
                    })
                });

                const data = await response.json();

                // Hide typing indicator
                document.getElementById('typingIndicator').style.display = 'none';

                // Format response
                let responseHtml = `<strong>${selectedProvider === 'all' ? 'Multi-AI' : selectedProvider}</strong><br>${data.response}`;

                // Add sources if available
                if (data.sources && data.sources.length > 0) {
                    responseHtml += '<div class="sources-list"><strong>Sources:</strong><br>';
                    data.sources.forEach(source => {
                        responseHtml += `• ${source.id}: ${source.title}<br>`;
                    });
                    responseHtml += '</div>';
                }

                responseHtml += `<div class="message-meta">Confidence: ${(data.confidence * 100).toFixed(0)}% | Time: ${data.processing_time.toFixed(2)}s</div>`;

                addMessage(responseHtml, 'bot');

            } catch (error) {
                document.getElementById('typingIndicator').style.display = 'none';
                addMessage('Error: ' + error.message, 'bot');
            }
        }

        function addMessage(content, type) {
            const messagesDiv = document.getElementById('chatMessages');
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${type}`;
            messageDiv.innerHTML = type === 'user' ? content : content;
            messagesDiv.appendChild(messageDiv);
            messagesDiv.scrollTop = messagesDiv.scrollHeight;
        }

        function handleChatKeyPress(event) {
            if (event.key === 'Enter') {
                sendChatMessage();
            }
        }

        // Load projects
        async function loadProjects() {
            const response = await fetch('/projects');
            const projects = await response.json();

            const listDiv = document.getElementById('projectsList');
            const selects = ['genProjectId', 'analyzeProjectId', 'uploadProjectId'];

            listDiv.innerHTML = '';
            selects.forEach(id => {
                const element = document.getElementById(id);
                if (element) {
                    element.innerHTML = '<option value="">Select Project</option>';
                }
            });

            projects.forEach(project => {
                listDiv.innerHTML += `
                    <div class="requirement-item">
                        <div class="requirement-header">
                            <span class="requirement-id">${project.name}</span>
                            <span class="pegs-badge">${project.domain}</span>
                        </div>
                        <p>${project.description}</p>
                        <small>Created: ${new Date(project.created_at).toLocaleDateString()}</small>
                    </div>
                `;

                selects.forEach(id => {
                    const element = document.getElementById(id);
                    if (element) {
                        element.innerHTML += `<option value="${project.id}">${project.name} (${project.domain})</option>`;
                    }
                });
            });
        }

        // Create project
        async function createProject() {
            const name = document.getElementById('projectName').value;
            const domain = document.getElementById('projectDomain').value;
            const description = document.getElementById('projectDesc').value;

            if (!name || !description) {
                alert('Please fill all fields');
                return;
            }

            const response = await fetch('/projects', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({name, domain, description})
            });

            if (response.ok) {
                alert('Project created successfully!');
                document.getElementById('projectName').value = '';
                document.getElementById('projectDesc').value = '';
                loadProjects();
            }
        }

        // Generate requirements
        async function generateRequirements() {
            const projectId = document.getElementById('genProjectId').value;
            const pegsFocus = document.getElementById('pegsFocus').value;
            const count = parseInt(document.getElementById('reqCount').value);

            if (!projectId) {
                alert('Please select a project');
                return;
            }

            const domain = document.getElementById('genProjectId').selectedOptions[0].text.match(/\(([^)]+)\)/)[1];

            const response = await fetch('/requirements/generate', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    project_id: parseInt(projectId),
                    domain: domain,
                    pegs_focus: pegsFocus || null,
                    count: count
                })
            });

            const data = await response.json();

            const resultsDiv = document.getElementById('generatedReqs');
            resultsDiv.innerHTML = `
                <div class="message success" style="background: #d4edda; color: #155724; padding: 15px; border-radius: 10px;">
                    Generated ${data.generated_count} requirements successfully!
                </div>
                <div class="requirements-list" style="margin-top: 20px;">
                    ${data.requirements.map(req => `
                        <div class="requirement-item">
                            <div class="requirement-header">
                                <span class="requirement-id">${req.requirement_id}</span>
                                <span class="pegs-badge">${req.pegs_category}</span>
                            </div>
                            <h4>${req.title}</h4>
                            <p>${req.description}</p>
                            <small>Priority: ${req.priority} | Confidence: ${(req.confidence_score * 100).toFixed(0)}%</small>
                        </div>
                    `).join('')}
                </div>
            `;
        }

        // Analyze project
        async function analyzeProject() {
            const projectId = document.getElementById('analyzeProjectId').value;

            if (!projectId) {
                alert('Please select a project');
                return;
            }

            const response = await fetch(`/analyze/${projectId}`, {
                method: 'POST'
            });

            const data = await response.json();

            // Display scores
            const scoresDiv = document.getElementById('pegsScores');
            scoresDiv.innerHTML = Object.entries(data.pegs_scores).map(([category, score]) => `
                <div class="pegs-card">
                    <h3>${category}</h3>
                    <div style="font-size: 2rem; color: #667eea;">${score.toFixed(1)}%</div>
                    <div style="margin-top: 10px;">
                        <div style="background: #e0e0e0; height: 10px; border-radius: 5px;">
                            <div style="background: linear-gradient(135deg, #667eea, #764ba2); width: ${score}%; height: 100%; border-radius: 5px;"></div>
                        </div>
                    </div>
                </div>
            `).join('');

            // Display recommendations
            const recsDiv = document.getElementById('recommendations');
            recsDiv.innerHTML = `
                <h3>Recommendations</h3>
                <ul style="margin-top: 10px;">
                    ${data.recommendations.map(rec => `<li>${rec}</li>`).join('')}
                </ul>
            `;
        }

        // File upload
        document.getElementById('fileInput').addEventListener('change', async (e) => {
            const file = e.target.files[0];
            const projectId = document.getElementById('uploadProjectId').value;

            if (!projectId) {
                alert('Please select a project first');
                return;
            }

            const formData = new FormData();
            formData.append('file', file);

            const response = await fetch(`/upload/${projectId}`, {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            document.getElementById('uploadResults').innerHTML = `
                <div class="message success" style="background: #d4edda; color: #155724; padding: 15px; border-radius: 10px;">
                    Extracted ${data.requirements_saved} requirements from ${data.filename}
                </div>
                <div class="pegs-grid">
                    ${Object.entries(data.extraction_summary).map(([category, count]) => `
                        <div class="pegs-card">
                            <h3>${category}</h3>
                            <div style="font-size: 2rem; color: #667eea;">${count}</div>
                            <p>Requirements</p>
                        </div>
                    `).join('')}
                </div>
            `;
        });

        // Initialize
        loadProjects();
    </script>
</body>
</html>"""


if __name__ == "__main__":
    import uvicorn
    # Replit requires host 0.0.0.0
    uvicorn.run(app, host="0.0.0.0", port=8000)
