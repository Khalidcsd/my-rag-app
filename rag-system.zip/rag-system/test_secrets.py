import os

print("Testing API Keys:")
print(f"GROQ: {'✓' if os.getenv('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') else '✗'}")
print(f"OPENAI: {'✓' if os.getenv('OPENAI_API_KEY') else '✗'}")
print(f"ANTHROPIC: {'✓' if os.getenv('ANTHROPIC_API_KEY') else '✗'}")
